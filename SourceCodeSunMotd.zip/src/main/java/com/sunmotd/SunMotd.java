package com.sunmotd;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;

public final class SunMotd extends JavaPlugin {

    private String line1;
    private String line2;
    private String reloadMessage;
    private String noPermissionMessage;
    private String usageMessage;
    private String helpMessage; // Новое поле для сообщения справки
    private int fakeOnline; // Новое поле для фейкового онлайна

    @Override
    public void onEnable() {
        // Plugin startup logic
        saveDefaultConfig(); // Сохраняем дефолтный конфиг, если его нет
        loadConfig(); // Загружаем конфиг
        getServer().getPluginManager().registerEvents(new MotdListener(this), this);
    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }

    private void loadConfig() {
        getLogger().info("Пытаюсь загрузить конфигурацию...");
        reloadConfig();
        FileConfiguration config = getConfig();

        line1 = ChatColor.translateAlternateColorCodes('&', config.getString("messages.line1", "&x&F&F&5&3&0&0&lS&x&F&F&6&B&0&0&lu&x&F&F&8&3&0&0&ln&x&F&F&9&B&0&0&lM&x&F&F&B&3&0&0&lo&x&F&F&C&B&0&0&lt&x&F&F&E&3&0&0&ld"));
        line2 = ChatColor.translateAlternateColorCodes('&', config.getString("messages.line2", "&eThe SunMotd plugin is available on SpigotMc"));
        reloadMessage = ChatColor.translateAlternateColorCodes('&', config.getString("messages.reload", "&aКонфигурация SunMotd перезагружена!"));
        noPermissionMessage = ChatColor.translateAlternateColorCodes('&', config.getString("messages.noPermission", "&cУ вас нет разрешения на выполнение этой команды."));
        usageMessage = ChatColor.translateAlternateColorCodes('&', config.getString("messages.usage", "&cИспользуйте: /sunmotd reload для перезагрузки конфигурации."));
        fakeOnline = config.getInt("fakeOnline", 0);

        List<String> helpList = config.getStringList("help");
        StringBuilder helpMessageBuilder = new StringBuilder();
        for (String line : helpList) {
            helpMessageBuilder.append(ChatColor.translateAlternateColorCodes('&', line)).append("\n");
        }
        helpMessage = helpMessageBuilder.toString();


        getLogger().info("Configuration loaded successfully!");
    }


    public String getLine1() {
        return line1;
    }

    public String getLine2() {
        return line2;
    }

    public int getFakeOnline() {
        return fakeOnline;
    }

    // Метод для обновления значения фейкового онлайна
    public void setFakeOnline(int online) {
        this.fakeOnline = online;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("sunmotd")) {
            if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
                sender.sendMessage(helpMessage); // Отправляем сообщение справки
                return true;
            }

            if (!sender.hasPermission("sunmotd.reload")) {
                sender.sendMessage(ChatColor.RED + "You do not have permission to run this command.");
                return true;
            }

            if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
                reloadConfig();
                loadConfig();
                sender.sendMessage(ChatColor.GREEN + "SunMotd configuration reloaded!");
                return true;
            } else {
                sender.sendMessage(ChatColor.RED + "Use: /sunmotd reload to reload the configuration.");
                return true;
            }
        }
        return false;
    }
}