package com.sunmotd;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.server.ServerListPingEvent;

public class MotdListener implements Listener {

    private final SunMotd plugin;

    public MotdListener(SunMotd plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onServerListPing(ServerListPingEvent event) {
        event.setMotd(plugin.getLine1() + "\n" + plugin.getLine2());
    }
}
